import os, runpy
_g = runpy.run_path(os.path.join(os.path.dirname(__file__), 'views.pyc'), run_name=__name__)
globals().update(_g)
